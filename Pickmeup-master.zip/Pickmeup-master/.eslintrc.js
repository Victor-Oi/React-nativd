module.exports = {
  root: true,
  extends: '@react-native-community',
  rules: {
    'prettier/prettier': 0,
    "react-hooks/exhaustive-deps":0,
    "react-hooks/rules-of-hooks":0,
  },
};
