import React from 'react';
import { View } from 'react-native';

import { TextView } from './styles';

const login = () => {
  return (
    <View>
      <TextView>login Screen</TextView>
    </View>
  );
};

export default login;
