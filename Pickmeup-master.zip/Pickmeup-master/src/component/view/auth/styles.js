import styled from 'styled-components/native';
import Text from '../../widget/text';

export const TextView = styled(Text)`

`;
