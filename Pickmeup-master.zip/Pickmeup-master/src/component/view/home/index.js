import React from 'react';
import { View } from 'react-native';

import { TextView } from './styles';

const Home = () => {
  return (
    <View>
    <TextView>Home</TextView>
  </View>
  );
};

export default Home;
