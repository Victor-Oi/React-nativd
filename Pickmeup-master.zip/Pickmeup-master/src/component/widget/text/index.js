import React from 'react';

import {TextView} from './styles';

const Text = (props) => {
  return <TextView {...props}/>;
};

export default Text;
