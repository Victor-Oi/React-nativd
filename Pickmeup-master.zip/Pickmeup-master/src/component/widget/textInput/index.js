import React from 'react';

import { TextInputView } from './styles';

const TextInput = (props) => {
  return <TextInputView {...props} />;
};

export default TextInput;
