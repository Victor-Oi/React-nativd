import styled from 'styled-components/native';

export const  TextInputView = styled.TextInput`
`;
