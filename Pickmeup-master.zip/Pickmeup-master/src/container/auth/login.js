import React from 'react';

import LoginView from '../../component/view/auth/login';

const login = () => {
  return <LoginView />;
};

export default login;
