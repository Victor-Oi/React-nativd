import React from 'react';
import HomeView  from '../../component/view/home';


const Home = () => {
  return <HomeView/>;
};

export default Home;
